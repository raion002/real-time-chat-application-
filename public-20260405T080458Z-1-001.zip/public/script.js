const socket = io();

// State
let myProfile = null;
let currentServerId = null;
let currentChannelId = null;
let replyingToMessageId = null;
let reactingToMessageId = null;
let isHomeView = false;
let typingUsers = new Map(); // userId -> username
let typingTimeout = null;

// DOM Elements
const dynamicSpacesEl = document.getElementById('dynamic-spaces');
const messagesEl = document.getElementById('messages');
const chatForm = document.getElementById('chat-form');
const messageInput = document.getElementById('message-input');
const currentServerNameEl = document.getElementById('current-server-name');
const editServerBtn = document.getElementById('edit-server-btn');
const currentChannelNameEl = document.getElementById('current-channel-name');
const modalMembersListEl = document.getElementById('modal-members-list');
const onlineMembersStackEl = document.getElementById('online-members-stack');
const onlineCountEl = document.getElementById('online-count');
const typingIndicatorEl = document.getElementById('typing-indicator');

const chatView = document.getElementById('chat-view');
const homeView = document.getElementById('home-view');
const chatHeaderContainer = document.getElementById('chat-header-container');
const homeHeaderContainer = document.getElementById('home-header-container');
const homeIcon = document.getElementById('home-icon');

// Socket Initial Connection
socket.on('me', (profile) => {
    myProfile = profile;
    document.getElementById('my-avatar').src = profile.avatar;
    document.getElementById('my-username').textContent = profile.username;
    document.getElementById('my-subtext').textContent = `#${profile.discriminator}`;
});

// Switch to Home View (DMs)
function goHome() {
    isHomeView = true;
    currentServerId = null;
    currentChannelId = null;
    
    // Update active icon
    document.querySelectorAll('.space-header').forEach(el => el.classList.remove('active'));
    homeIcon.classList.add('active');

    // Toggle Views
    chatView.style.display = 'none';
    chatHeaderContainer.style.display = 'none';
    homeView.style.display = 'flex';
    homeHeaderContainer.style.display = 'flex';
    
    // Collapse all space channels
    document.querySelectorAll('.space-channels').forEach(el => el.style.display = 'none');
    
    if (editServerBtn) editServerBtn.style.display = 'none';
}

window.goHome = goHome;

// Receive Server List
socket.on('user servers', (userServers) => {
    dynamicSpacesEl.innerHTML = '';
    
    userServers.forEach(srv => {
        const groupEl = document.createElement('div');
        groupEl.className = 'space-group';
        groupEl.id = `space-${srv.id}`;
        
        const headerEl = document.createElement('div');
        headerEl.className = `space-header ${srv.id === currentServerId ? 'active' : ''}`;
        headerEl.innerHTML = `
            <div class="space-letter">${srv.name.charAt(0).toUpperCase()}</div>
            <span>${srv.name}</span>
        `;
        headerEl.onclick = () => selectServer(srv.id);
        
        const channelsContainer = document.createElement('div');
        channelsContainer.className = 'space-channels';
        channelsContainer.id = `channels-${srv.id}`;
        channelsContainer.style.display = (srv.id === currentServerId) ? 'flex' : 'none';
        
        groupEl.appendChild(headerEl);
        groupEl.appendChild(channelsContainer);
        dynamicSpacesEl.appendChild(groupEl);
    });

    if (!currentServerId && !isHomeView && userServers.length > 0) {
        selectServer(userServers[0].id);
    } else if (!currentServerId && userServers.length === 0) {
        goHome();
    } else if (currentServerId) {
        if (userServers.find(s => s.id === currentServerId)) {
            socket.emit('get server state', currentServerId, (res) => {
                if (res.success) renderServerData(res.server);
            });
        } else {
            goHome();
        }
    }
});

function selectServer(serverId) {
    isHomeView = false;
    currentServerId = serverId;
    
    homeIcon.classList.remove('active');
    document.querySelectorAll('.space-header').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.space-channels').forEach(el => el.style.display = 'none');
    
    const activeHeader = document.querySelector(`#space-${serverId} .space-header`);
    if(activeHeader) activeHeader.classList.add('active');
    
    const activeChannels = document.getElementById(`channels-${serverId}`);
    if(activeChannels) activeChannels.style.display = 'flex';

    homeView.style.display = 'none';
    homeHeaderContainer.style.display = 'none';
    chatView.style.display = 'flex';
    chatHeaderContainer.style.display = 'flex';

    if (editServerBtn) editServerBtn.style.display = 'flex';

    socket.emit('get server state', serverId, (res) => {
        if (res.success) renderServerData(res.server);
    });
}

function renderServerData(serverData) {
    currentServerNameEl.textContent = serverData.name;
    
    const channelsContainer = document.getElementById(`channels-${serverData.id}`);
    if(channelsContainer) {
        channelsContainer.innerHTML = '';
        serverData.channels.forEach(channel => {
            const chEl = document.createElement('div');
            chEl.className = `nav-channel ${channel.id === currentChannelId ? 'active' : ''}`;
            chEl.innerHTML = `<span class="hash">#</span> ${channel.name}`;
            chEl.onclick = (e) => {
                e.stopPropagation(); 
                selectChannel(channel.id, channel.name, serverData.messages[channel.id]);
            };
            channelsContainer.appendChild(chEl);
        });
        
        const addChEl = document.createElement('div');
        addChEl.className = 'add-channel-item';
        addChEl.innerHTML = `+ Add Channel`;
        addChEl.onclick = (e) => {
            e.stopPropagation();
            openChannelModal();
        };
        channelsContainer.appendChild(addChEl);
    }

    updateMembersList(serverData.members);

    if (serverData.channels.length > 0) {
        if (!currentChannelId || !serverData.channels.find(c => c.id === currentChannelId)) {
            selectChannel(serverData.channels[0].id, serverData.channels[0].name, serverData.messages[serverData.channels[0].id]);
        }
    } else {
        currentChannelId = null;
        messageInput.disabled = true;
        messageInput.placeholder = "No channels available.";
        messagesEl.innerHTML = '';
    }
}

function selectChannel(channelId, channelName, messagesHistory) {
    currentChannelId = channelId;
    currentChannelNameEl.textContent = channelName;
    
    document.querySelectorAll('.nav-channel').forEach(el => el.classList.remove('active'));
    const allChannels = Array.from(document.querySelectorAll('.nav-channel'));
    const activeCh = allChannels.find(el => el.innerText.includes(channelName));
    if(activeCh) activeCh.classList.add('active');

    messageInput.disabled = false;
    messageInput.placeholder = `Message #${channelName}`;
    messageInput.focus();

    typingUsers.clear();
    updateTypingIndicator();

    messagesEl.innerHTML = `
        <div class="welcome-banner">
            <div class="icon-circle"><span class="hash">#</span></div>
            <h1>Welcome to #${channelName}!</h1>
            <p>This is the start of the #${channelName} channel.</p>
        </div>
    `;
    
    if (messagesHistory) {
        messagesHistory.forEach(appendMessage);
    }
    
    scrollToBottom();
}

function updateMembersList(membersArray) {
    modalMembersListEl.innerHTML = '';
    onlineMembersStackEl.innerHTML = '';
    onlineCountEl.textContent = membersArray.length;
    
    const displayMembers = membersArray.slice(0, 3);
    displayMembers.forEach(member => {
        const img = document.createElement('img');
        img.src = member.avatar;
        img.className = 'stack-avatar';
        onlineMembersStackEl.appendChild(img);
    });
    
    if (membersArray.length > 3) {
        const moreCount = document.createElement('div');
        moreCount.className = 'stack-avatar';
        moreCount.style.display = 'flex';
        moreCount.style.justifyContent = 'center';
        moreCount.style.alignItems = 'center';
        moreCount.style.fontSize = '10px';
        moreCount.style.color = 'white';
        moreCount.style.background = 'var(--glass-bg)';
        moreCount.textContent = `+${membersArray.length - 3}`;
        onlineMembersStackEl.appendChild(moreCount);
    }
    
    membersArray.forEach(member => {
        const mEl = document.createElement('div');
        mEl.className = 'member';
        mEl.innerHTML = `
            <div class="avatar">
                <img src="${member.avatar}" alt="${member.username}">
                <div class="status online"></div>
            </div>
            <div class="name">${member.username}</div>
        `;
        modalMembersListEl.appendChild(mEl);
    });
}

// Typing Indicator Logic
messageInput.addEventListener('input', () => {
    if (!currentServerId || !currentChannelId) return;

    socket.emit('typing', { serverId: currentServerId, channelId: currentChannelId, isTyping: true });

    if (typingTimeout) clearTimeout(typingTimeout);

    typingTimeout = setTimeout(() => {
        socket.emit('typing', { serverId: currentServerId, channelId: currentChannelId, isTyping: false });
    }, 2000);
});

socket.on('typing', (data) => {
    if (data.serverId !== currentServerId || data.channelId !== currentChannelId) return;

    if (data.isTyping) {
        typingUsers.set(data.userId, data.username);
    } else {
        typingUsers.delete(data.userId);
    }
    updateTypingIndicator();
});

function updateTypingIndicator() {
    if (typingUsers.size === 0) {
        typingIndicatorEl.classList.remove('active');
        typingIndicatorEl.textContent = '';
        return;
    }

    const unames = Array.from(typingUsers.values());
    let text = '';
    if (unames.length === 1) text = `${unames[0]} is typing...`;
    else if (unames.length === 2) text = `${unames[0]} and ${unames[1]} are typing...`;
    else text = "Several people are typing...";

    typingIndicatorEl.textContent = text;
    typingIndicatorEl.classList.add('active');
}

// Chat Sending
chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    if (messageInput.value.trim() && currentServerId && currentChannelId) {
        const text = messageInput.value.trim();
        socket.emit('chat message', {
            serverId: currentServerId,
            channelId: currentChannelId,
            text: text,
            replyTo: replyingToMessageId
        });
        
        socket.emit('typing', { serverId: currentServerId, channelId: currentChannelId, isTyping: false });
        if (typingTimeout) clearTimeout(typingTimeout);

        messageInput.value = '';
        if (window.cancelReply) window.cancelReply();
    }
});

socket.on('chat message', (data) => {
    if (data.serverId === currentServerId && data.channelId === currentChannelId) {
        appendMessage(data.message);
        scrollToBottom();
    }
});

function appendMessage(msg) {
    const lastMsgEl = messagesEl.lastElementChild;
    const isConsecutive = lastMsgEl 
        && lastMsgEl.dataset.senderId === msg.sender.id 
        && !msg.reply_to
        && (new Date(msg.timestamp) - new Date(lastMsgEl.dataset.timestamp)) < 5 * 60 * 1000;

    const msgEl = document.createElement('div');
    msgEl.className = 'message' + (isConsecutive ? ' compact' : '');
    msgEl.dataset.id = msg.id;
    msgEl.dataset.senderId = msg.sender.id;
    msgEl.dataset.timestamp = msg.timestamp;
    
    const timeString = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const editedHtml = msg.edited ? `<span class="msg-edited">(edited)</span>` : '';

    let replyHtml = '';
    if (msg.reply_to) {
        replyHtml = `
            <div class="msg-reply-preview">
                <div class="reply-spine"></div>
                <span class="reply-username">@${msg.reply_to.username}</span>
                <span class="reply-text">${escapeHtml(msg.reply_to.text).substring(0, 60)}...</span>
            </div>
        `;
    }

    let reactionsHtml = '<div class="msg-reactions" id="reactions-' + msg.id + '">';
    for (const [emoji, users] of Object.entries(msg.reactions || {})) {
        if (users.length > 0) {
            const hasReacted = myProfile ? users.includes(myProfile.id) : false;
            reactionsHtml += `
                <button class="reaction-badge ${hasReacted ? 'active' : ''}" onclick="toggleReaction('${msg.id}', '${emoji}')(event)">
                    ${emoji} <span class="count">${users.length}</span>
                </button>
            `;
        }
    }
    reactionsHtml += '</div>';

    let actionsHtml = `
        <div class="message-actions">
            <button class="m-action-btn hover-pop tooltipped" aria-label="React" onclick="openReactionPicker(event, '${msg.id}')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S7.83 8 7 8s-1.5.67-1.5 1.5S7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/></svg>
            </button>
            <button class="m-action-btn hover-pop tooltipped" aria-label="Reply" onclick="startReply('${msg.id}', '${escapeHtml(msg.sender.username).replace(/'/g, "\\'")}', '${escapeHtml(msg.text).replace(/'/g, "\\'")}')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11z"/></svg>
            </button>
    `;
    
    if (myProfile && msg.sender.id === myProfile.id) {
        actionsHtml += `
            <button class="m-action-btn edit hover-pop tooltipped" aria-label="Edit" onclick="startEdit('${msg.id}')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
            </button>
            <button class="m-action-btn delete hover-pop tooltipped" aria-label="Delete" onclick="deleteMessage('${msg.id}')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
            </button>
        `;
    }
    actionsHtml += "</div>";

    let parsedText = typeof parseMarkdown === 'function' ? parseMarkdown(escapeHtml(msg.text)) : escapeHtml(msg.text);

    if (isConsecutive) {
        msgEl.innerHTML = `
            ${actionsHtml}
            <div class="compact-timestamp">${timeString}</div>
            <div class="msg-content">${parsedText}${editedHtml}</div>
            ${reactionsHtml}
        `;
    } else {
        msgEl.innerHTML = `
            ${replyHtml}
            <img src="${msg.sender.avatar}" alt="Avatar" class="msg-avatar ${msg.reply_to ? 'avatar-with-reply' : ''}">
            ${actionsHtml}
            <div class="msg-header ${msg.reply_to ? 'header-with-reply' : ''}">
                <span class="msg-username">${msg.sender.username}</span>
                <span class="msg-timestamp">Today at ${timeString}</span>
            </div>
            <div class="msg-content ${msg.reply_to ? 'content-with-reply' : ''}">${parsedText}${editedHtml}</div>
            ${reactionsHtml}
        `;
    }

    messagesEl.appendChild(msgEl);
}

socket.on('message edited', (data) => {
    if (data.serverId === currentServerId && data.channelId === currentChannelId) {
        const msgEl = document.querySelector(`.message[data-id="${data.messageId}"]`);
        if (msgEl) {
            const contentEl = msgEl.querySelector('.msg-content');
            contentEl.innerHTML = `${escapeHtml(data.newText)}<span class="msg-edited">(edited)</span>`;
        }
    }
});

socket.on('message deleted', (data) => {
    if (data.serverId === currentServerId && data.channelId === currentChannelId) {
        const msgEl = document.querySelector(`.message[data-id="${data.messageId}"]`);
        if (msgEl) msgEl.remove();
    }
});

window.startEdit = function(messageId) {
    const msgEl = document.querySelector(`.message[data-id="${messageId}"]`);
    if (!msgEl) return;
    
    const contentEl = msgEl.querySelector('.msg-content');
    const currentText = contentEl.innerText.replace('(edited)', '').trim();
    
    contentEl.innerHTML = `
        <div class="edit-input-container">
            <input type="text" id="edit-input-${messageId}" value="${escapeHtml(currentText)}">
        </div>
        <div style="font-size: 10px; color: var(--text-muted); margin-top:2px; margin-left: 2px;">escape to cancel • enter to save</div>
    `;
    
    const inputEl = document.getElementById(`edit-input-${messageId}`);
    inputEl.focus();

    inputEl.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            contentEl.innerHTML = `${escapeHtml(currentText)}`; 
        } else if (e.key === 'Enter') {
            e.preventDefault();
            const newText = inputEl.value.trim();
            if (newText && newText !== currentText) {
                socket.emit('edit message', {
                    serverId: currentServerId,
                    channelId: currentChannelId,
                    messageId: messageId,
                    newText: newText
                });
            } else {
                contentEl.innerHTML = `${escapeHtml(currentText)}`;
            }
        }
    });
};

window.deleteMessage = function(messageId) {
    if(confirm('Are you sure you want to delete this message?')) {
        socket.emit('delete message', {
            serverId: currentServerId,
            channelId: currentChannelId,
            messageId: messageId
        });
    }
};

function scrollToBottom() {
    messagesEl.scrollTop = messagesEl.scrollHeight;
}

function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

socket.on('server members update', (data) => {
    if (data.serverId === currentServerId) {
        updateMembersList(data.members);
    }
});

socket.on('channel created', (data) => {
    if (data.serverId === currentServerId) {
        selectServer(currentServerId);
    }
});

socket.on('server renamed', (data) => {
    // Update the sidebar item
    const spaceHeaderSpan = document.querySelector(`#space-${data.serverId} .space-header span`);
    const spaceHeaderLetter = document.querySelector(`#space-${data.serverId} .space-header .space-letter`);
    if (spaceHeaderSpan) spaceHeaderSpan.textContent = data.newName;
    if (spaceHeaderLetter) spaceHeaderLetter.textContent = data.newName.charAt(0).toUpperCase();

    // Update the current view if it's the renamed server
    if (data.serverId === currentServerId) {
        currentServerNameEl.textContent = data.newName;
    }
});

// Modals
window.openServerModal = function() {
    document.getElementById('server-modal').style.display = 'flex';
}

window.openEditServerModal = function() {
    if (currentServerId) {
        document.getElementById('edit-server-name').value = currentServerNameEl.textContent;
        document.getElementById('edit-server-modal').style.display = 'flex';
    }
}

window.openChannelModal = function() {
    document.getElementById('channel-modal').style.display = 'flex';
}

window.openMembersModal = function() {
    document.getElementById('members-modal').style.display = 'flex';
}

window.closeModal = function(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

window.closeModalOnBg = function(e, modalId) {
    if (e.target.id === modalId) {
        closeModal(modalId);
    }
}

// Forms
document.getElementById('edit-server-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const newName = document.getElementById('edit-server-name').value.trim();
    if (newName && currentServerId) {
        socket.emit('rename server', { serverId: currentServerId, newName }, (res) => {
            if (res.success) {
                closeModal('edit-server-modal');
            }
        });
    }
});

document.getElementById('create-server-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('new-server-name').value;
    socket.emit('create server', name, (res) => {
        if(res.success) closeModal('server-modal');
    });
});

document.getElementById('join-server-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const code = document.getElementById('join-server-code').value;
    socket.emit('join server', code, (res) => {
        if(res.success) {
            closeModal('server-modal');
        } else {
            alert(res.message);
        }
    });
});

document.getElementById('create-channel-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('new-channel-name').value;
    socket.emit('create channel', { serverId: currentServerId, channelName: name }, (res) => {
        if(res.success) closeModal('channel-modal');
    });
});

window.showServerCode = function() {
    if(currentServerId) {
        alert("Invite friends to " + currentServerNameEl.textContent + " with this code: " + currentServerId);
    }
}

// Parsers & Feature Logic
function parseMarkdown(text) {
    let parsed = text;
    parsed = parsed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    parsed = parsed.replace(/\*(.*?)\*/g, '<em>$1</em>');
    parsed = parsed.replace(/~~(.*?)~~/g, '<del>$1</del>');
    parsed = parsed.replace(/`(.*?)`/g, '<code class="inline-code">$1</code>');
    return parsed;
}

window.startReply = function(messageId, username, text) {
    replyingToMessageId = messageId;
    const banner = document.getElementById('reply-banner');
    if(banner) {
        banner.style.display = 'flex';
        document.getElementById('reply-banner-name').textContent = username;
        document.getElementById('reply-banner-text').textContent = text.length > 50 ? text.substring(0, 50) + "..." : text;
    }
    messageInput.focus();
};

window.cancelReply = function() {
    replyingToMessageId = null;
    const banner = document.getElementById('reply-banner');
    if(banner) banner.style.display = 'none';
};

const reactionPicker = document.getElementById('reaction-picker');

window.openReactionPicker = function(event, messageId) {
    reactingToMessageId = messageId;
    if(reactionPicker) {
        reactionPicker.style.display = 'block';
        reactionPicker.style.left = (event.pageX - 120) + 'px'; 
        reactionPicker.style.top = (event.pageY - 50) + 'px';
        
        const hidePicker = (e) => {
            if (!reactionPicker.contains(e.target) && !e.target.closest('.m-action-btn')) {
                reactionPicker.style.display = 'none';
                document.removeEventListener('click', hidePicker);
            }
        };
        setTimeout(() => document.addEventListener('click', hidePicker), 10);
    }
};

window.sendReaction = function(emoji) {
    if (reactingToMessageId && currentServerId && currentChannelId) {
        socket.emit('add reaction', {
            serverId: currentServerId,
            channelId: currentChannelId,
            messageId: reactingToMessageId,
            emoji: emoji
        });
    }
    if(reactionPicker) reactionPicker.style.display = 'none';
};

window.toggleReaction = function(messageId, emoji) {
    return function(event) {
        const isAdding = !event.currentTarget.classList.contains('active');
        socket.emit(isAdding ? 'add reaction' : 'remove reaction', {
            serverId: currentServerId,
            channelId: currentChannelId,
            messageId: messageId,
            emoji: emoji
        });
    }
};

socket.on('reaction updated', (data) => {
    if (data.serverId === currentServerId && data.channelId === currentChannelId) {
        socket.emit('get server state', currentServerId, (res) => {
            if(res.success) {
                const msg = res.server.messages[currentChannelId].find(m => m.id === data.messageId);
                if (msg) {
                    const reactionsContainer = document.getElementById(`reactions-${msg.id}`);
                    if (reactionsContainer) {
                        let reactionsHtml = '';
                        for (const [emoji, users] of Object.entries(msg.reactions || {})) {
                            if (users.length > 0) {
                                const hasReacted = myProfile ? users.includes(myProfile.id) : false;
                                reactionsHtml += `
                                    <button class="reaction-badge ${hasReacted ? 'active' : ''}" onclick="toggleReaction('${msg.id}', '${emoji}')(event)">
                                        ${emoji} <span class="count">${users.length}</span>
                                    </button>
                                `;
                            }
                        }
                        reactionsContainer.innerHTML = reactionsHtml;
                    }
                }
            }
        });
    }
});

// Initializing UI State on load
goHome();
